# from phone_login.models import AbstractUser

"""
This test is when user wants to change his existing phone number
with a new phone number
"""
